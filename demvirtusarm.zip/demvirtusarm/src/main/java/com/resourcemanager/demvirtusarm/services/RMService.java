package com.resourcemanager.demvirtusarm.services;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import com.resourcemanager.demvirtusarm.models.RelationalManager;
import com.resourcemanager.demvirtusarm.repositories.RMRepository;
import com.virtusa.kafkaappointmentconsumer.dto.Appointment;
//import com.virtusa.banking.appointment.models.Appointment;


@Service
public class RMService {
    @Autowired
	private RMRepository rmRepo;
    @Autowired
    private RestTemplate restTemplateGet;
    private RestTemplate restTemplateDelete;
    //@Value("${authUrl}")
	//private String authUrl;
	@Value("${serviceUri}")
	private String serviceUrl;
  //insert the appointment

  	public List<RelationalManager> getAllRelationalManager()
  	{
  		return this.rmRepo.findAll();
  	}
  	
	/*
	 * public ResponseEntity<String> getAppointmentById(long appointmentId) {
	 * Appointment responseAppointment=null; //ResponseEntity<String>
	 * responseAppointment =restTemplate.exchange(serviceUrl+
	 * appointmentId,HttpMethod.GET,null,);
	 * 
	 * return response;
	 * 
	 * }
	 */
	public List<Appointment> getAppointmentByRmId(long rmId)
  	{
		//ResponseEntity<String>
		//List<Appointment> response 
		ResponseEntity<List> entity=restTemplateGet.exchange(serviceUrl+"rm/"+
  				rmId,HttpMethod.GET,null,List.class);	
		return entity.getBody() != null? entity.getBody() :                          
            Collections.emptyList();
  	}
	
	public void deleteAppointmentsById(long appId)
	{
		ResponseEntity<Boolean> entity =restTemplateDelete.exchange(serviceUrl+
				 appId,HttpMethod.DELETE,null,Boolean.class);
	}

	public void updateAppointmentsById(Appointment appointment)
	{
		ResponseEntity<Appointment> entity =restTemplateDelete.exchange(serviceUrl,HttpMethod.PUT,new HttpEntity<Appointment>(appointment),Appointment.class);
	}
	
	public void updateAppointmentStatus(long appId,String status)
	{
		ResponseEntity<Appointment> entity =restTemplateDelete.exchange(serviceUrl+appId+"/RM/"+status,HttpMethod.PUT,null,Appointment.class);
	}
	
	
	public RelationalManager updateAppointment(RelationalManager relationalManager)
	{
			return this.rmRepo.save(relationalManager);
	}

}
