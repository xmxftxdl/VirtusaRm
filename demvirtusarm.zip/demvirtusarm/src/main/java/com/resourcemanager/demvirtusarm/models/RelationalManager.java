package com.resourcemanager.demvirtusarm.models;


import java.time.LocalDate;
import java.time.LocalTime;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
//import lombok.Data;

@Entity
@Table(name="tmp")
public class RelationalManager {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="RM_Id")
    private long rmId;
	@Column(name="Num_Appointments")
    private int numAppointments;
	
	
	public long getRMId() {
		return rmId;
	}
	public void setNumAppointments(int num) {
		this.numAppointments = num;
	}
	public int getNumAppointments() {
		return numAppointments;
	}
	public void setRmId(long rmId) {
		this.rmId = rmId;
	}
}
